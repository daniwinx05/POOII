﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;

namespace BDWpfApp1Empregado
{
    internal class Empregado
    {
        public int Matricula { get; set; }
        public string? Nome { get; set; }
        public string? CPF { get; set; }
        public string? Endereco { get; set; }

        public Empregado() { }

        public Empregado(string cpf, string nome, string endereco)
        {
            CPF = cpf;
            Nome = nome;
            Endereco = endereco;
        }

        public void Salvar(SqlConnection conexao)
        {
            try
            {
                Console.WriteLine("======= Salvando Empregado ========");
                if (Matricula == 0)
                {
                    using var cmd = conexao.CreateCommand();
                    cmd.CommandText = "INSERT INTO Empregado (CPF, Nome, Endereco) VALUES (@cpf, @nome, @endereco)";
                    cmd.Parameters.AddWithValue("@cpf", CPF);
                    cmd.Parameters.AddWithValue("@nome", Nome);
                    cmd.Parameters.AddWithValue("@endereco", Endereco);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao salvar: {ex.Message}");
            }
        }

        public List<Empregado> Pesquisar(int matriculaParam, SqlConnection conexao)
        {
            Console.WriteLine("====== Recuperando Empregado ======");
            List<Empregado> empregadosLidos = new();

            using var cmd = conexao.CreateCommand();

            if (matriculaParam == 0)
            {
                cmd.CommandText = "SELECT * FROM Empregado";
            }
            else
            {
                cmd.CommandText = "SELECT * FROM Empregado WHERE Matricula = @matriculaBusca";
                cmd.Parameters.AddWithValue("@matriculaBusca", matriculaParam);
            }

            using var reader = cmd.ExecuteReader();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    Empregado emp = new()
                    {
                        Matricula = reader.GetInt32("Matricula"),
                        CPF = reader.GetString("CPF"),
                        Nome = reader.GetString("Nome"),
                        Endereco = reader.GetString("Endereco")
                    };
                    empregadosLidos.Add(emp);
                }
            }

            return empregadosLidos;
        }

        public override string ToString()
        {
            return $"Empregado -> Matricula: {Matricula} | CPF: {CPF} | Nome: {Nome} | Endereço: {Endereco}";
        }
    }
}
