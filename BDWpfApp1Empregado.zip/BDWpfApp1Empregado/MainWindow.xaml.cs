﻿using Microsoft.Data.SqlClient;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;

namespace BDWpfApp1Empregado
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection? conexao = null;
        BindingList<Empregado> objClasseListDataGridEmpregado = new ();



        public MainWindow()
        {
            InitializeComponent();
            DataGridEmpregadoList.ItemsSource = objClasseListDataGridEmpregado;
            string URL = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=BDEmpregadoGUID;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";
            
           
            try {
                conexao = new SqlConnection(URL);

                conexao.Open();
                LabelStatus.Content = "Conexão OK";
            }
            catch(Exception e) {
                LabelStatus.Content = "Conexão NOT";
                Console.WriteLine(e.Message);
            }
            

        }

        private bool VerificarCampos()
        {
            return TextBoxMatricula.Text == "" &&
                TextBoxNome.Text != "" &&
                TextBoxCPF.Text != "" &&
                TextBoxEndereco.Text != "";
        }




        private void LimparCampos()
        {
            TextBoxMatricula.Text = "";
            TextBoxCPF.Text = "";
            TextBoxEndereco.Text = "";
            TextBoxNome.Text = "";
        }





        private void ButtonSalvar_Click(object sender, RoutedEventArgs e)
        {
            Empregado emp = new()
            {
                CPF = TextBoxCPF.Text,
                Nome = TextBoxNome.Text,
                Endereco = TextBoxEndereco.Text,
            };
            if (conexao != null && VerificarCampos())
            {
                emp.Salvar(conexao);
                List<Empregado> ret = emp.Pesquisar(0, conexao);

                LimparCampos();

                


                if (ret != null)
                {
                    LabelStatus.Content = "Pesquisa OK";
                    objClasseListDataGridEmpregado = new(ret);
                    DataGridEmpregadoList.ItemsSource = objClasseListDataGridEmpregado;

                }

            }
            else {
                LabelStatus.Content = "Conexão NOT";
            }

        }



        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ButtonPesquisar_Click(object sender, RoutedEventArgs e)
        {
            Empregado emp = new();
            List<Empregado>? ret = null;

            if (conexao != null)
            {

                if (TextBoxMatricula.Text == "")
                {
                    ret = emp.Pesquisar(0, conexao);
                }
                else
                {
                    if (int.TryParse(TextBoxMatricula.Text, out int matricula))
                    {
                        ret = emp.Pesquisar(matricula, conexao);
                    }
                    else
                    {
                        LabelStatus.Content = "Matrícula inválida";
                        return;
                    }


                }
            }
                if (ret != null) 
                {
                    LabelStatus.Content = "Pesquisa OK";
                    objClasseListDataGridEmpregado.Clear();
                    foreach (var item in ret)
                        objClasseListDataGridEmpregado.Add(item);


            }


            LimparCampos();

        }
    }
}